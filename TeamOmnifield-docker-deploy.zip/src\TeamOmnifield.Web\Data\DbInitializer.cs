using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using TeamOmnifield.Web.Models;

namespace TeamOmnifield.Web.Data;

public static class DbInitializer
{
    public static async Task InitializeAsync(AppDbContext db, IPasswordHasher<AdminUser> hasher)
    {
        for (var attempt = 1; attempt <= 20; attempt++)
        {
            try
            {
                await db.Database.EnsureCreatedAsync();
                break;
            }
            catch when (attempt < 20)
            {
                await Task.Delay(1000);
            }
        }

        if (!await db.Categories.AnyAsync())
        {
            var categories = new[]
            {
                new Category { Name = "Biryani", DisplayOrder = 1 },
                new Category { Name = "Starters", DisplayOrder = 2 },
                new Category { Name = "Meals", DisplayOrder = 3 },
                new Category { Name = "Beverages", DisplayOrder = 4 },
                new Category { Name = "Desserts", DisplayOrder = 5 }
            };
            db.Categories.AddRange(categories);
            await db.SaveChangesAsync();
        }

        await db.Database.ExecuteSqlRawAsync("""ALTER TABLE "Products" ADD COLUMN IF NOT EXISTS "ImageUrl" text NOT NULL DEFAULT ''""");
        await db.Database.ExecuteSqlRawAsync("""CREATE UNIQUE INDEX IF NOT EXISTS "IX_Products_Name_Unique" ON "Products" (LOWER("Name"))""");
        await db.Database.ExecuteSqlRawAsync("""ALTER TABLE "Orders" ADD COLUMN IF NOT EXISTS "PaymentMethod" text NOT NULL DEFAULT ''""");

        {
            var categories = await db.Categories.ToDictionaryAsync(x => x.Name);
            var existingNames = (await db.Products.Select(x => x.Name).ToListAsync())
                .ToHashSet(StringComparer.OrdinalIgnoreCase);

            var missing = ProductSeeds
                .Where(seed => !existingNames.Contains(seed.Name))
                .Select(seed => new Product
                {
                    CategoryId = categories[seed.CategoryName].Id,
                    Name = seed.Name,
                    Description = seed.Description,
                    Price = seed.Price,
                    ImageUrl = ProductImages.TryGetValue(seed.Name, out var url) ? url : DefaultImage
                })
                .ToList();

            if (missing.Count > 0)
            {
                db.Products.AddRange(missing);
                await db.SaveChangesAsync();
            }

            // loremflickr links are random and often fail to load; swap them for the curated photos.
            var unpictured = await db.Products.Where(x => x.ImageUrl == "" || x.ImageUrl.Contains("loremflickr.com")).ToListAsync();
            foreach (var product in unpictured)
            {
                product.ImageUrl = ProductImages.TryGetValue(product.Name, out var url) ? url : DefaultImage;
            }
            if (unpictured.Count > 0) await db.SaveChangesAsync();
        }

        // Seeded per account, so an existing database still picks up accounts added later.
        var seededUsers = new[]
        {
            ("admin@htrestaurant.com", "HT Restaurant Owner"),
            ("developer@htrestaurant.com", "TeamOmnifield Consultant"),
        };

        var added = false;
        foreach (var (email, displayName) in seededUsers)
        {
            if (await db.AdminUsers.AnyAsync(x => x.Email == email)) continue;
            var user = new AdminUser { Email = email, DisplayName = displayName };
            user.PasswordHash = hasher.HashPassword(user, "Admin@12345");
            db.AdminUsers.Add(user);
            added = true;
        }
        if (added) await db.SaveChangesAsync();
    }

    private const string DefaultImage = "https://images.pexels.com/photos/5410418/pexels-photo-5410418.jpeg?auto=compress&cs=tinysrgb&w=800&h=600&fit=crop";

    private sealed record ProductSeed(string CategoryName, string Name, string Description, decimal Price);

    private static readonly ProductSeed[] ProductSeeds =
    {
        new("Biryani", "Chicken Biryani", "Aromatic basmati rice with chicken and traditional spices.", 180),
        new("Biryani", "Mutton Biryani", "Slow-cooked mutton biryani with fragrant rice.", 240),
        new("Biryani", "Egg Biryani", "Fragrant basmati rice layered with spiced boiled eggs.", 140),
        new("Biryani", "Veg Biryani", "Basmati rice cooked with mixed vegetables and biryani spices.", 150),
        new("Biryani", "Paneer Biryani", "Basmati rice with marinated paneer cubes and whole spices.", 170),
        new("Biryani", "Prawns Biryani", "Fragrant rice layered with spiced, tender prawns.", 260),

        new("Starters", "Chicken 65", "Crispy, spicy South Indian chicken starter.", 160),
        new("Starters", "Fish 65", "Crispy, spicy South Indian fish starter.", 180),
        new("Starters", "Prawn 65", "Crispy, spicy South Indian prawn starter.", 200),
        new("Starters", "Chilli Chicken", "Indo-Chinese stir-fried chicken with peppers and spicy sauce.", 170),
        new("Starters", "Chicken Lollipop", "Frenched chicken wings tossed in a spicy coating.", 180),
        new("Starters", "Grill Chicken", "Marinated chicken grilled to perfection.", 500),
        new("Starters", "Fish Fry", "Crisp, spice-marinated fried fish fillets.", 190),
        new("Starters", "Paneer Tikka", "Char-grilled marinated paneer cubes with peppers and onions.", 160),
        new("Starters", "Gobi Manchurian", "Crispy cauliflower florets tossed in a tangy Manchurian sauce.", 130),

        new("Meals", "Veg Meals", "Traditional vegetarian meal with sides.", 130),
        new("Meals", "Chicken Meals", "Steamed rice served with chicken curry and traditional sides.", 170),
        new("Meals", "Fish Meals", "Steamed rice served with fish curry and traditional sides.", 180),
        new("Meals", "Mutton Meals", "Steamed rice served with mutton curry and traditional sides.", 220),

        new("Beverages", "Fresh Lime", "Refreshing lime drink.", 50),
        new("Beverages", "Mango Lassi", "Chilled yogurt drink blended with sweet mango pulp.", 70),
        new("Beverages", "Masala Lassi", "Spiced buttermilk with curry leaves and roasted cumin.", 40),
        new("Beverages", "Tea", "Traditional Indian tea brewed with spices.", 20),
        new("Beverages", "Coffee", "Freshly brewed Indian coffee.", 30),
        new("Beverages", "Cold Coffee", "Creamy chilled coffee blended with milk and ice.", 80),
        new("Beverages", "Fresh Orange Juice", "Freshly squeezed orange juice, served chilled.", 70),
        new("Beverages", "Apple Juice", "Freshly pressed apple juice, served chilled.", 80),
        new("Beverages", "Mango Juice", "Freshly squeezed mango juice, served chilled.", 70),
        new("Beverages", "Pineapple Juice", "Freshly squeezed pineapple juice, served chilled.", 80),
        new("Beverages", "Watermelon Juice", "Freshly squeezed watermelon juice, served chilled.", 30),
        new("Beverages", "Pomegranate Juice", "Freshly squeezed pomegranate juice, served chilled.", 80),

        new("Desserts", "Gulab Jamun", "Sweet Indian dessert made of milk solids.", 80),
        new("Desserts", "Rasmalai", "Soft paneer discs soaked in sweetened, cardamom-flavoured milk.", 90),
        new("Desserts", "Kesari", "Saffron-flavoured semolina sweet garnished with cashews.", 60),
        new("Desserts", "Vanilla Ice Cream", "Classic creamy vanilla ice cream scoop.", 70)
    };

    private static readonly Dictionary<string, string> ProductImages = new()
    {
        ["Chicken Biryani"] = "https://i.pinimg.com/736x/85/55/00/8555006fc4ae16ae59e8c004d53a3203.jpg",
        ["Mutton Biryani"] = "https://i0.wp.com/blendofspicesbysara.com/wp-content/uploads/2021/06/PXL_20210523_214147714.PORTRAIT-01.jpeg?resize=800%2C840&ssl=1",
        ["Egg Biryani"] = "https://www.pavaniskitchen.com/wp-content/uploads/2021/04/egg-biryani-recipe.jpg",
        ["Veg Biryani"] = "https://www.indianhealthyrecipes.com/wp-content/uploads/2021/09/veg-biryani-vegetable-biryani.jpg",
        ["Paneer Biryani"] = "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcREAWpX8hFs7bpx-8V3_Kdv3SiFZYqCRcttCJK36KEA5w&s=10",
        ["Prawns Biryani"] = "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSf8j6F8_hbvGRO5hcA4MNTjYWSYBpTY-1bec7QevP9nQ&s=10",

        ["Chicken 65"] = "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQTOdg2heULjokz8u9ZGpbCCf3MqTSyzfSU20imV23aOA&s=10",
        ["Fish 65"] = "https://www.namscorner.com/wp-content/uploads/2020/09/fish_65/119977574_348322912960340_7000921242004451602_n-1.jpg",
        ["Prawn 65"] = "https://i.pinimg.com/736x/80/3c/a3/803ca3a82d089f7ef3eca09a876a24a6.jpg",
        ["Chilli Chicken"] = "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQXMx_i3LkPTVIWq1TxhfO8sC7_vDdJLc8579BrhA-nbQ&s=10",
        ["Chicken Lollipop"] = "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTxzxRygtklQbufkySE8eYIiCHdGEFQbMIHOLbJTtupqRPEb2t7Cv1DKQmM&s=10",
        ["Grill Chicken"] = "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSKhoQWUsO6xgeFcZdo8bJKfbsrm4VS8yzPz0mFQbnnqvoIHghp_r9SlNc&s=10",
        ["Fish Fry"] = "https://media.istockphoto.com/id/1363859965/photo/fish-fry.jpg?s=612x612&w=0&k=20&c=tX3SCNk7y5JZrewLAZX5BoLptXWOWS7KIEndwQrvxBY=",
        ["Paneer Tikka"] = "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQFrOUCKUEJwTIuTFqzRWyPYZB7ONFm-sZY2yEy4yN97WdByQFozCw_OmQ&s=10",
        ["Gobi Manchurian"] = "https://i.pinimg.com/564x/10/27/e3/1027e3903bf3209c8f2ec356170e9fc7.jpg",

        ["Veg Meals"] = "https://i.pinimg.com/736x/7c/af/bb/7cafbb86397b8dce09cf0df4af25dafd.jpg",
        ["Chicken Meals"] = "https://www.cooking4allseasons.com/wp-content/uploads/2018/06/Andhra-Style-Chicken-Gravy-500x375.jpg",
        ["Fish Meals"] = "https://i.pinimg.com/736x/14/c1/1e/14c11eca9a59aa89823d2e43e26368f4.jpg",
        ["Mutton Meals"] = "https://i.pinimg.com/736x/9d/cf/a5/9dcfa5b5241b107b64109be776b0c9d5.jpg",

        ["Fresh Lime"] = "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT5jqPiwuFirnXEsHX8SjjL03NLA7SfKCbAyKWn3933IA&s=10",
        ["Mango Lassi"] = "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTOFScd-wAOiJdv4MXsuPXJN81-zgMCpu4EJJN8S-0Hdw&s=10",
        ["Masala Lassi"] = "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSF8TsSgf-CJe-vUK7cRidaBM6bkovUSXtjepuOyZdUIDYWEG0XONYEhA4&s=10",
        ["Tea"] = "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSck0R1QadchlbSdfFbDk0DsOEJKV8VuCD3ltycnyLbig&s",
        ["Coffee"] = "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTwc45iPOVXL-gxnCBA-XUX00HdDlhOix0RxwpzNRBzBw&s=10",
        ["Cold Coffee"] = "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTKCZvaMBWO4UTxeLmHt8YbmEwCvRItWcwQPtYaNLuH8g&s=10",
        ["Apple Juice"] = "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTlfuTQXtqrg7n5udBD81Wg8nhtKyp8b8IPrzp2-DYSNg&s=10",
        ["Mango Juice"] = "https://i.pinimg.com/474x/10/06/d9/1006d93ae757a062819c413b7af49805.jpg?nii=t",
        ["Pineapple Juice"] = "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTZQjzeZ9EWgOKX5E14bOyG0_MXGzoL0TvREiyLi-2M7A&s=10",
        ["Watermelon Juice"] = "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSzKIuyf1rSr8uW4nOxs0TsHMIadXbDt7t-YYgJS53Rdw&s",
        ["Pomegranate Juice"] = "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQG3Qy1PGX58O8tjUJBhcMQxKrHrkHi8plsL0MmBHOTfw&s=10",

        ["Orange Juice"] = "https://images.unsplash.com/photo-1600271886742-f049cd451bba?fm=jpg&q=60&w=3000&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D",
        ["Egg Meals"] = "https://images.pexels.com/photos/9110581/pexels-photo-9110581.jpeg?auto=compress&cs=tinysrgb&w=800&h=600&fit=crop",
        ["Masala Chaas"] = "https://images.pexels.com/photos/8489749/pexels-photo-8489749.jpeg?auto=compress&cs=tinysrgb&w=800&h=600&fit=crop",
        ["Fresh Orange Juice"] = "https://images.pexels.com/photos/14510445/pexels-photo-14510445.jpeg?auto=compress&cs=tinysrgb&w=800&h=600&fit=crop",
        ["Double Ka Meetha"] = "https://images.pexels.com/photos/20446398/pexels-photo-20446398.jpeg?auto=compress&cs=tinysrgb&w=800&h=600&fit=crop",
        ["Gulab Jamun"] = "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQYpTSsKHP5fZfdx7qFP18Yf4bkFtkW2dc_wqdo2tpOOQ&s=10",
        ["Rasmalai"] = "https://i.pinimg.com/474x/48/54/af/4854af9296311829470f1c7494165f72.jpg",
        ["Kesari"] = "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRVq92hV6jILJktCh78jV3HK8znEpXyYmy48E1DyEaHnQ&s=10",
        ["Vanilla Ice Cream"] = "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSE7Rdll6lx8mgvwphVb4SI4hx98bOPmYcZyXQECsUx9UnbK3hrTBV9Q3c&s=10"
    };
}
